import { motion } from 'framer-motion';
import { BookOpen, Brain, Users, FileText, ArrowUpRight } from 'lucide-react';

const features = [
  {
    icon: BookOpen,
    title: '课程中心',
    desc: '按科目/学段分类的优质课程，覆盖高考全科目',
    link: '#/courses',
  },
  {
    icon: Brain,
    title: '知识评测',
    desc: 'AI智能测评，精准定位薄弱环节，生成个性化报告',
    link: '#/assessment',
  },
  {
    icon: Users,
    title: '名师辅导',
    desc: '专业名师一对一答疑解惑，针对性提升学习效率',
    link: '#/courses',
  },
  {
    icon: FileText,
    title: '免费资料',
    desc: '海量学习资料免费领取，真题试卷与学霸笔记',
    link: '#/materials',
  },
];

export default function Features() {
  return (
    <section className="py-32 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <span className="text-xs font-medium tracking-widest text-slate-400 uppercase mb-4 block">
            Our Services
          </span>
          <h2 className="text-3xl lg:text-4xl font-semibold text-slate-900 tracking-tight">
            核心服务
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-slate-200">
          {features.map((feature, index) => (
            <motion.a
              key={feature.title}
              href={feature.link}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group bg-white p-10 lg:p-12 hover:bg-slate-50 transition-colors relative"
            >
              <div className="flex items-start justify-between mb-8">
                <feature.icon className="w-8 h-8 text-slate-700 stroke-[1.5]" />
                <ArrowUpRight className="w-5 h-5 text-slate-300 group-hover:text-slate-600 transition-colors" />
              </div>
              <h3 className="text-xl font-semibold text-slate-900 mb-3 tracking-tight">
                {feature.title}
              </h3>
              <p className="text-sm text-slate-500 leading-relaxed">
                {feature.desc}
              </p>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}
