import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section className="relative min-h-screen flex items-center bg-white pt-20">
      <div className="max-w-6xl mx-auto px-6 lg:px-8 w-full">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-xs font-medium tracking-widest text-slate-400 uppercase mb-6 block">
              Professional Education Platform
            </span>
            
            <h1 className="text-5xl lg:text-6xl font-semibold text-slate-900 mb-8 leading-[1.1] tracking-tight">
              专注提分
              <br />
              <span className="text-sky-600">成就未来</span>
            </h1>

            <p className="text-lg text-slate-500 mb-4 max-w-md leading-relaxed">
              汇聚名师资源，提供个性化学习方案
            </p>
            <p className="text-base text-slate-400 mb-12 max-w-md">
              课程中心 · 知识评测 · 名师辅导 · 免费资料
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="#/courses"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-slate-900 text-white text-sm font-medium hover:bg-slate-800 transition-colors"
              >
                开始探索
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#/about"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-slate-200 text-slate-700 text-sm font-medium hover:border-slate-400 hover:text-slate-900 transition-colors"
              >
                了解更多
              </a>
            </div>

            <div className="mt-16 flex items-center gap-12">
              <div>
                <div className="text-2xl font-semibold text-slate-900">50万+</div>
                <div className="text-xs text-slate-400 mt-1">学员信赖</div>
              </div>
              <div className="w-px h-10 bg-slate-200" />
              <div>
                <div className="text-2xl font-semibold text-slate-900">1000+</div>
                <div className="text-xs text-slate-400 mt-1">精品课程</div>
              </div>
              <div className="w-px h-10 bg-slate-200" />
              <div>
                <div className="text-2xl font-semibold text-slate-900">98%</div>
                <div className="text-xs text-slate-400 mt-1">好评率</div>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative hidden lg:block"
          >
            <div className="aspect-[4/3] bg-slate-100 relative overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=800&h=600&fit=crop"
                alt="Education"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-white/20 to-transparent" />
            </div>
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-sky-50 -z-10" />
            <div className="absolute -top-6 -right-6 w-24 h-24 border border-slate-200 -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
