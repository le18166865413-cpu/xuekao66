import { motion } from 'framer-motion';
import { ArrowUpRight } from 'lucide-react';

const courses = [
  {
    id: 1,
    title: '高考数学冲刺班',
    teacher: '张老师',
    students: 2580,
    price: 1299,
    image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=600&h=400&fit=crop',
    tag: '热门',
  },
  {
    id: 2,
    title: '英语语法精讲',
    teacher: '李老师',
    students: 1890,
    price: 899,
    image: 'https://images.unsplash.com/photo-1543269865-cbf427effbad?w=600&h=400&fit=crop',
    tag: '推荐',
  },
  {
    id: 3,
    title: '物理高分攻略',
    teacher: '王老师',
    students: 1200,
    price: 1099,
    image: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=600&h=400&fit=crop',
    tag: '新课',
  },
  {
    id: 4,
    title: '化学实验专项',
    teacher: '赵老师',
    students: 980,
    price: 799,
    image: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=600&h=400&fit=crop',
    tag: '特色',
  },
];

export default function Courses() {
  return (
    <section className="py-32 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="flex items-end justify-between mb-16"
        >
          <div>
            <span className="text-xs font-medium tracking-widest text-slate-400 uppercase mb-4 block">
              Popular Courses
            </span>
            <h2 className="text-3xl lg:text-4xl font-semibold text-slate-900 tracking-tight">
              热门课程
            </h2>
          </div>
          <a
            href="#/courses"
            className="text-sm text-slate-600 hover:text-slate-900 font-medium flex items-center gap-1 transition-colors"
          >
            查看全部
            <ArrowUpRight className="w-4 h-4" />
          </a>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {courses.map((course, index) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group cursor-pointer"
            >
              <div className="aspect-[3/2] bg-slate-100 mb-5 overflow-hidden">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
              </div>
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="text-lg font-semibold text-slate-900">{course.title}</h3>
                    <span className="text-xs text-sky-600 font-medium">{course.tag}</span>
                  </div>
                  <p className="text-sm text-slate-500">{course.teacher} · {course.students}人在学</p>
                </div>
                <div className="text-right">
                  <span className="text-lg font-semibold text-slate-900">¥{course.price}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
