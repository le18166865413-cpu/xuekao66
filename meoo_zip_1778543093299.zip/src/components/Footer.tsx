import { motion } from 'framer-motion';
import { GraduationCap } from 'lucide-react';

const quickLinks = [
  { name: '课程中心', href: '#/courses' },
  { name: '知识评测', href: '#/assessment' },
  { name: '免费资料', href: '#/materials' },
  { name: '关于我们', href: '#/about' },
];

const services = [
  { name: '在线课程', href: '#/courses' },
  { name: 'AI测评', href: '#/assessment' },
  { name: '名师辅导', href: '#/courses' },
  { name: '学习资料', href: '#/materials' },
];

export default function Footer() {
  return (
    <footer className="bg-white border-t border-slate-200">
      <div className="max-w-6xl mx-auto px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="md:col-span-1"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 bg-slate-900 flex items-center justify-center">
                <GraduationCap className="w-6 h-6 text-white" />
              </div>
              <span className="text-lg font-semibold text-slate-900">学考合一</span>
            </div>
            <p className="text-slate-500 text-sm leading-relaxed">
              专注教育提分，汇聚名师资源，为每一位学生提供个性化的学习方案。
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
          >
            <h3 className="text-sm font-semibold text-slate-900 mb-4 uppercase tracking-wider">快速链接</h3>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.name}>
                  <a
                    href={link.href}
                    className="text-sm text-slate-500 hover:text-slate-900 transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
          >
            <h3 className="text-sm font-semibold text-slate-900 mb-4 uppercase tracking-wider">服务项目</h3>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service.name}>
                  <a
                    href={service.href}
                    className="text-sm text-slate-500 hover:text-slate-900 transition-colors"
                  >
                    {service.name}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
          >
            <h3 className="text-sm font-semibold text-slate-900 mb-4 uppercase tracking-wider">联系我们</h3>
            <ul className="space-y-3 text-sm text-slate-500">
              <li>400-888-9999</li>
              <li>contact@xuekao.com</li>
              <li>北京市海淀区中关村大街1号</li>
            </ul>
          </motion.div>
        </div>
      </div>

      <div className="border-t border-slate-200">
        <div className="max-w-6xl mx-auto px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-slate-400 text-xs">
              © 2024 学考合一教育科技有限公司 版权所有
            </p>
            <div className="flex gap-6 text-xs">
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors">隐私政策</a>
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors">服务条款</a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
