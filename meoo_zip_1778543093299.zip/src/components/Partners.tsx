import { motion } from 'framer-motion';

const partners = [
  { name: '清华大学' },
  { name: '北京大学' },
  { name: '复旦大学' },
  { name: '浙江大学' },
  { name: '南京大学' },
  { name: '武汉大学' },
  { name: '中山大学' },
  { name: '四川大学' },
];

export default function Partners() {
  return (
    <section className="py-24 bg-white">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-16"
        >
          <span className="text-xs font-medium tracking-widest text-slate-400 uppercase mb-4 block">
            Partners
          </span>
          <h2 className="text-3xl lg:text-4xl font-semibold text-slate-900 tracking-tight">
            合作院校
          </h2>
        </motion.div>

        <div className="grid grid-cols-4 md:grid-cols-8 gap-px bg-slate-200">
          {partners.map((partner, index) => (
            <motion.div
              key={partner.name}
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className="bg-white p-6 flex items-center justify-center aspect-square hover:bg-slate-50 transition-colors"
            >
              <span className="text-sm text-slate-400 font-medium text-center">
                {partner.name}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
