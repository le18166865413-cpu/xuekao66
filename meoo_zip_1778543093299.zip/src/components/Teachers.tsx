import { motion } from 'framer-motion';

const teachers = [
  { id: 1, name: '张明华', subject: '数学', years: 15, image: 'https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop', desc: '特级教师，高考命题研究专家' },
  { id: 2, name: '李雅琴', subject: '英语', years: 12, image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=500&fit=crop', desc: '雅思8.5分，口语教学专家' },
  { id: 3, name: '王建国', subject: '物理', years: 18, image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=500&fit=crop', desc: '物理奥赛金牌教练' },
  { id: 4, name: '赵丽芳', subject: '化学', years: 10, image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=500&fit=crop', desc: '化学实验教学名师' },
];

export default function Teachers() {
  return (
    <section className="py-32 bg-slate-50">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <span className="text-xs font-medium tracking-widest text-slate-400 uppercase mb-4 block">
            Our Team
          </span>
          <h2 className="text-3xl lg:text-4xl font-semibold text-slate-900 tracking-tight">
            师资力量
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {teachers.map((teacher, index) => (
            <motion.div
              key={teacher.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group"
            >
              <div className="aspect-[3/4] bg-slate-200 mb-5 overflow-hidden">
                <img
                  src={teacher.image}
                  alt={teacher.name}
                  className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-500"
                />
              </div>
              <div className="space-y-1">
                <div className="flex items-center gap-3">
                  <h3 className="text-lg font-semibold text-slate-900">{teacher.name}</h3>
                  <span className="text-xs text-sky-600 font-medium">{teacher.subject}</span>
                </div>
                <p className="text-xs text-slate-400">{teacher.years}年教龄 · {teacher.desc}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
