import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';

export default function CTA() {
  return (
    <section className="py-32 bg-slate-900">
      <div className="max-w-4xl mx-auto px-6 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="space-y-8"
        >
          <h2 className="text-3xl lg:text-4xl font-semibold text-white tracking-tight">
            开启你的提分之旅
          </h2>
          
          <p className="text-slate-400 text-lg max-w-xl mx-auto leading-relaxed">
            立即注册，免费体验AI智能测评，获取个性化学习方案
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <a
              href="#/register"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-slate-900 text-sm font-medium hover:bg-slate-100 transition-colors"
            >
              免费注册
              <ArrowRight className="w-4 h-4" />
            </a>
            <a
              href="#/courses"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 border border-slate-600 text-white text-sm font-medium hover:border-slate-400 transition-colors"
            >
              浏览课程
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
