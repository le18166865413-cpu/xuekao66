import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Menu, X, GraduationCap } from 'lucide-react';

const navItems = [
  { name: '首页', href: '#/' },
  { name: '课程中心', href: '#/courses' },
  { name: '知识评测', href: '#/assessment' },
  { name: '免费资料', href: '#/materials' },
  { name: '关于我们', href: '#/about' },
];

export default function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <motion.header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white/95 backdrop-blur-sm border-b border-slate-100' : 'bg-transparent'
      }`}
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          <motion.a
            href="#/"
            className="flex items-center gap-3"
            whileHover={{ opacity: 0.8 }}
          >
            <div className="w-10 h-10 bg-slate-900 flex items-center justify-center">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <span className="text-lg font-semibold tracking-tight text-slate-900">学考合一</span>
          </motion.a>

          <nav className="hidden lg:flex items-center gap-10">
            {navItems.map((item) => (
              <motion.a
                key={item.name}
                href={item.href}
                className="text-sm text-slate-600 hover:text-slate-900 font-medium tracking-wide transition-colors relative py-2"
                whileHover={{ y: -1 }}
              >
                {item.name}
              </motion.a>
            ))}
          </nav>

          <div className="hidden lg:flex items-center gap-4">
            <motion.button
              className="text-sm text-slate-600 hover:text-slate-900 font-medium transition-colors px-4 py-2"
              whileHover={{ y: -1 }}
            >
              登录
            </motion.button>
            <motion.button
              className="text-sm font-medium bg-slate-900 text-white px-5 py-2.5 hover:bg-slate-800 transition-colors"
              whileHover={{ y: -1 }}
              whileTap={{ scale: 0.98 }}
            >
              免费注册
            </motion.button>
          </div>

          <button
            className="lg:hidden text-slate-900 p-2"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            className="lg:hidden bg-white border-t border-slate-100"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
          >
            <div className="px-6 py-6 space-y-1">
              {navItems.map((item) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="block py-3 text-slate-600 hover:text-slate-900 font-medium"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  {item.name}
                </a>
              ))}
              <div className="pt-4 border-t border-slate-100 space-y-2 mt-4">
                <button className="w-full py-3 text-slate-600 hover:text-slate-900 font-medium text-left">
                  登录
                </button>
                <button className="w-full py-3 bg-slate-900 text-white font-medium">
                  免费注册
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.header>
  );
}
