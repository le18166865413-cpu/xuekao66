import { motion } from 'framer-motion';

const testimonials = [
  {
    id: 1,
    name: '张同学',
    school: '北京大学',
    content: '学考合一的课程让我从班级中游逆袭到年级前十，数学单科提升了40分。系统的学习方法和名师的指导让我找到了学习的方向。',
    subject: '高考数学冲刺班',
  },
  {
    id: 2,
    name: '李同学',
    school: '清华大学',
    content: '知识评测系统精准定位我的薄弱环节，针对性学习让效率翻倍。最终成功考入理想院校，感谢学考合一的专业服务。',
    subject: 'AI智能测评',
  },
  {
    id: 3,
    name: '王同学',
    school: '复旦大学',
    content: '名师一对一辅导，英语从90分提升到135分。老师不仅传授知识，更教会了我学习的方法和思维方式。',
    subject: '英语一对一辅导',
  },
];

export default function Testimonials() {
  return (
    <section className="py-32 bg-slate-900">
      <div className="max-w-6xl mx-auto px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mb-20"
        >
          <span className="text-xs font-medium tracking-widest text-slate-500 uppercase mb-4 block">
            Testimonials
          </span>
          <h2 className="text-3xl lg:text-4xl font-semibold text-white tracking-tight">
            学员评价
          </h2>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-slate-800">
          {testimonials.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="bg-slate-900 p-10 lg:p-12"
            >
              <p className="text-slate-300 text-sm leading-relaxed mb-8">
                "{item.content}"
              </p>
              <div className="border-t border-slate-800 pt-6">
                <div className="text-white font-medium">{item.name}</div>
                <div className="text-slate-500 text-sm">{item.school}</div>
                <div className="text-sky-400 text-xs mt-2">{item.subject}</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
