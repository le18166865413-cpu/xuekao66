import { motion, useInView } from 'framer-motion';
import { useRef, useEffect, useState } from 'react';

interface StatItemProps {
  value: number;
  suffix?: string;
  label: string;
  delay: number;
}

function AnimatedNumber({ value, suffix = '' }: { value: number; suffix?: string }) {
  const [displayValue, setDisplayValue] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      const duration = 2000;
      const steps = 60;
      const increment = value / steps;
      let current = 0;
      const timer = setInterval(() => {
        current += increment;
        if (current >= value) {
          setDisplayValue(value);
          clearInterval(timer);
        } else {
          setDisplayValue(Math.floor(current));
        }
      }, duration / steps);
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <span ref={ref} className="text-4xl lg:text-5xl font-semibold text-slate-900">
      {displayValue.toLocaleString()}{suffix}
    </span>
  );
}

function StatItem({ value, suffix, label, delay }: StatItemProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay }}
      className="text-center py-8"
    >
      <AnimatedNumber value={value} suffix={suffix} />
      <p className="text-slate-500 mt-3 text-sm tracking-wide">{label}</p>
    </motion.div>
  );
}

export default function Stats() {
  const stats = [
    { value: 50000, suffix: '+', label: '累计学员' },
    { value: 1200, suffix: '+', label: '精品课程' },
    { value: 96, suffix: '%', label: '提分通过率' },
    { value: 98, suffix: '%', label: '学员好评率' },
  ];

  return (
    <section className="py-20 bg-slate-50 border-y border-slate-200">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-px bg-slate-200">
          {stats.map((stat, index) => (
            <div key={index} className="bg-slate-50">
              <StatItem {...stat} delay={index * 0.1} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
