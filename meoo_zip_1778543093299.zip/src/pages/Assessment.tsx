import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Brain, Clock, CheckCircle, XCircle, ChevronRight, RotateCcw, Target, TrendingUp, Award, BookOpen, BarChart3 } from 'lucide-react';
import { supabase } from '../supabase/client';

const subjects = [
  { id: 'math', name: '数学', icon: '📐', fullScore: 150 },
  { id: 'english', name: '英语', icon: '🔤', fullScore: 150 },
  { id: 'physics', name: '物理', icon: '⚡', fullScore: 100 },
  { id: 'chemistry', name: '化学', icon: '⚗️', fullScore: 100 },
];

interface Question {
  id: string;
  question: string;
  options: string[];
  correct_answer: number;
  analysis: string;
  difficulty: string;
  knowledge_point: string;
  module: string;
  score: number;
}

interface AssessmentResult {
  score: number;
  totalScore: number;
  percentage: number;
  correctCount: number;
  totalCount: number;
  knowledgeStats: Record<string, { correct: number; total: number; score: number; totalScore: number }>;
  moduleStats: Record<string, { correct: number; total: number; score: number; totalScore: number }>;
  weakPoints: string[];
  strongPoints: string[];
  estimatedScoreRange: { min: number; max: number };
  suggestions: string[];
  difficultyStats: { simple: number; medium: number; hard: number };
}

export default function Assessment() {
  const [selectedSubject, setSelectedSubject] = useState<string | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [showAnalysis, setShowAnalysis] = useState<number | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AssessmentResult | null>(null);

  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (startTime && !showResult) {
      timer = setInterval(() => {
        setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [startTime, showResult]);

  const loadQuestions = async (subjectId: string) => {
    setLoading(true);
    const { data, error } = await supabase
      .from('assessment_questions')
      .select('*')
      .eq('subject', subjectId)
      .order('id');
    
    if (error) {
      console.error('加载题目失败:', error);
      setLoading(false);
      return;
    }

    const shuffled = data?.sort(() => Math.random() - 0.5).slice(0, 12) || [];
    setQuestions(shuffled);
    setLoading(false);
  };

  const selectSubject = async (subjectId: string) => {
    setSelectedSubject(subjectId);
    await loadQuestions(subjectId);
    setStartTime(Date.now());
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
    setElapsedTime(0);
    setShowAnalysis(null);
  };

  const selectAnswer = (optionIndex: number) => {
    const newAnswers = [...answers];
    newAnswers[currentQuestion] = optionIndex;
    setAnswers(newAnswers);
  };

  const nextQuestion = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setShowAnalysis(null);
    } else {
      generateResult();
    }
  };

  const generateResult = () => {
    let correctCount = 0;
    let totalScore = 0;
    let earnedScore = 0;
    
    const knowledgeStats: Record<string, { correct: number; total: number; score: number; totalScore: number }> = {};
    const moduleStats: Record<string, { correct: number; total: number; score: number; totalScore: number }> = {};
    const difficultyStats = { simple: 0, medium: 0, hard: 0 };

    questions.forEach((q, index) => {
      const isCorrect = answers[index] === q.correct_answer;
      const qScore = isCorrect ? q.score : 0;
      
      if (isCorrect) correctCount++;
      totalScore += q.score;
      earnedScore += qScore;

      if (!knowledgeStats[q.knowledge_point]) {
        knowledgeStats[q.knowledge_point] = { correct: 0, total: 0, score: 0, totalScore: 0 };
      }
      knowledgeStats[q.knowledge_point].total++;
      knowledgeStats[q.knowledge_point].totalScore += q.score;
      if (isCorrect) {
        knowledgeStats[q.knowledge_point].correct++;
        knowledgeStats[q.knowledge_point].score += q.score;
      }

      if (!moduleStats[q.module]) {
        moduleStats[q.module] = { correct: 0, total: 0, score: 0, totalScore: 0 };
      }
      moduleStats[q.module].total++;
      moduleStats[q.module].totalScore += q.score;
      if (isCorrect) {
        moduleStats[q.module].correct++;
        moduleStats[q.module].score += q.score;
      }

      difficultyStats[q.difficulty as keyof typeof difficultyStats]++;
    });

    const percentage = Math.round((earnedScore / totalScore) * 100);
    
    const weakPoints = Object.entries(knowledgeStats)
      .filter(([_, stats]) => stats.score / stats.totalScore < 0.6)
      .map(([knowledge]) => knowledge);
    
    const strongPoints = Object.entries(knowledgeStats)
      .filter(([_, stats]) => stats.score / stats.totalScore >= 0.8)
      .map(([knowledge]) => knowledge);

    const subjectInfo = subjects.find(s => s.id === selectedSubject);
    const fullScore = subjectInfo?.fullScore || 150;
    const estimatedMin = Math.round(fullScore * (percentage / 100) * 0.85);
    const estimatedMax = Math.round(fullScore * (percentage / 100) * 1.15);

    const suggestions = generateSuggestions(percentage, weakPoints, moduleStats);

    const assessmentResult: AssessmentResult = {
      score: earnedScore,
      totalScore,
      percentage,
      correctCount,
      totalCount: questions.length,
      knowledgeStats,
      moduleStats,
      weakPoints,
      strongPoints,
      estimatedScoreRange: { min: estimatedMin, max: estimatedMax },
      suggestions,
      difficultyStats
    };

    setResult(assessmentResult);
    setShowResult(true);
    saveResult(assessmentResult);
  };

  const generateSuggestions = (
    percentage: number,
    weakPoints: string[],
    moduleStats: Record<string, { correct: number; total: number; score: number; totalScore: number }>
  ): string[] => {
    const suggestions: string[] = [];
    
    if (percentage >= 85) {
      suggestions.push('基础扎实，建议适当挑战难题，冲击高分');
    } else if (percentage >= 60) {
      suggestions.push('基础较好，需要重点突破薄弱环节');
    } else {
      suggestions.push('建议系统复习基础知识，建立完整的知识体系');
    }

    if (weakPoints.length > 0) {
      suggestions.push(`重点攻克：${weakPoints.slice(0, 3).join('、')}等知识点`);
    }

    const weakModules = Object.entries(moduleStats)
      .filter(([_, stats]) => stats.score / stats.totalScore < 0.6)
      .map(([module]) => module);
    
    if (weakModules.length > 0) {
      suggestions.push(`加强模块：${weakModules.slice(0, 2).join('、')}`);
    }

    suggestions.push('建议每天保持30-60分钟专项练习');
    suggestions.push('定期回顾错题，总结解题思路');

    return suggestions;
  };

  const saveResult = async (assessmentResult: AssessmentResult) => {
    await supabase.from('assessment_results').insert({
      subject: selectedSubject,
      answers: answers.map((a, i) => ({ questionId: questions[i].id, answer: a })),
      score: assessmentResult.score,
      total_score: assessmentResult.totalScore,
      percentage: assessmentResult.percentage,
      time_spent: elapsedTime,
      weak_points: assessmentResult.weakPoints,
      suggestions: assessmentResult.suggestions,
      estimated_score_range: assessmentResult.estimatedScoreRange
    });
  };

  const resetAssessment = () => {
    setSelectedSubject(null);
    setQuestions([]);
    setCurrentQuestion(0);
    setAnswers([]);
    setShowResult(false);
    setStartTime(null);
    setElapsedTime(0);
    setShowAnalysis(null);
    setResult(null);
  };

  const restartAssessment = () => {
    if (selectedSubject) {
      loadQuestions(selectedSubject);
      setStartTime(Date.now());
      setCurrentQuestion(0);
      setAnswers([]);
      setShowResult(false);
      setElapsedTime(0);
      setShowAnalysis(null);
      setResult(null);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}分${secs.toString().padStart(2, '0')}秒`;
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case '简单': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case '中等': return 'bg-amber-50 text-amber-700 border-amber-200';
      case '较难': return 'bg-rose-50 text-rose-700 border-rose-200';
      default: return 'bg-slate-50 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="min-h-screen bg-white pt-20 pb-12">
      <div className="max-w-5xl mx-auto px-4">
        {!selectedSubject ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-12"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-100 text-slate-700 text-sm mb-6">
              <Brain className="w-4 h-4" />
              AI智能测评
            </div>
            <h1 className="text-4xl font-bold text-slate-900 tracking-tight mb-4">知识评测中心</h1>
            <p className="text-slate-500 mb-4 max-w-xl mx-auto">
              基于高考大纲的精准测评，覆盖核心考点，智能分析薄弱环节
            </p>
            <p className="text-sm text-slate-400 mb-12">每科12道精选题目 · 预估高考分数区间 · 个性化备考建议</p>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-3xl mx-auto">
              {subjects.map((subject) => (
                <motion.button
                  key={subject.id}
                  whileHover={{ y: -4 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => selectSubject(subject.id)}
                  className="p-6 border border-slate-200 hover:border-slate-400 transition-all bg-white"
                >
                  <div className="text-4xl mb-3">{subject.icon}</div>
                  <div className="font-semibold text-slate-900">{subject.name}</div>
                  <div className="text-sm text-slate-400 mt-1">满分{subject.fullScore}分</div>
                </motion.button>
              ))}
            </div>

            <div className="mt-16 grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              <div className="text-center py-6 border border-slate-100">
                <div className="text-3xl font-bold text-slate-900">48+</div>
                <div className="text-sm text-slate-500">精选题目</div>
              </div>
              <div className="text-center py-6 border border-slate-100">
                <div className="text-3xl font-bold text-slate-900">6大</div>
                <div className="text-sm text-slate-500">知识模块</div>
              </div>
              <div className="text-center py-6 border border-slate-100">
                <div className="text-3xl font-bold text-slate-900">AI</div>
                <div className="text-sm text-slate-500">智能分析</div>
              </div>
            </div>
          </motion.div>
        ) : loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <div className="w-12 h-12 border-2 border-slate-200 border-t-slate-900 animate-spin mx-auto mb-4"></div>
              <p className="text-slate-600">正在加载题目...</p>
            </div>
          </div>
        ) : !showResult ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="bg-white border border-slate-200 p-6 md:p-8"
          >
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-slate-900 tracking-tight">
                  {subjects.find(s => s.id === selectedSubject)?.name}测评
                </h2>
                <p className="text-sm text-slate-500">第 {currentQuestion + 1} / {questions.length} 题</p>
              </div>
              <div className="flex items-center gap-2 text-slate-700 bg-slate-50 px-4 py-2 border border-slate-200">
                <Clock className="w-4 h-4" />
                <span className="font-medium">{formatTime(elapsedTime)}</span>
              </div>
            </div>

            <div className="w-full bg-slate-100 h-1 mb-8">
              <div
                className="bg-slate-900 h-1 transition-all duration-300"
                style={{ width: `${((currentQuestion + 1) / questions.length) * 100}%` }}
              />
            </div>

            <AnimatePresence mode="wait">
              <motion.div
                key={currentQuestion}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
              >
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="px-3 py-1 bg-slate-100 text-slate-700 text-sm border border-slate-200">
                      {questions[currentQuestion]?.module}
                    </span>
                    <span className={`px-3 py-1 text-sm border ${getDifficultyColor(questions[currentQuestion]?.difficulty)}`}>
                      {questions[currentQuestion]?.difficulty}
                    </span>
                    <span className="px-3 py-1 bg-slate-50 text-slate-600 text-sm border border-slate-200">
                      {questions[currentQuestion]?.score}分
                    </span>
                  </div>
                  <h3 className="text-lg font-medium text-slate-900 leading-relaxed">
                    {questions[currentQuestion]?.question}
                  </h3>
                </div>

                <div className="space-y-3 mb-6">
                  {questions[currentQuestion]?.options.map((option, index) => (
                    <button
                      key={index}
                      onClick={() => selectAnswer(index)}
                      className={`w-full p-4 border-2 text-left transition-all ${
                        answers[currentQuestion] === index
                          ? 'border-slate-900 bg-slate-50'
                          : 'border-slate-200 hover:border-slate-400 hover:bg-slate-50'
                      }`}
                    >
                      <span className="font-medium mr-3 text-slate-400">{String.fromCharCode(65 + index)}.</span>
                      <span className="text-slate-800">{option}</span>
                    </button>
                  ))}
                </div>

                {showAnalysis === currentQuestion && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    className="bg-amber-50 border border-amber-200 p-4 mb-6"
                  >
                    <div className="flex items-start gap-3">
                      <BookOpen className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium text-amber-900 mb-1">解析</p>
                        <p className="text-amber-800 text-sm leading-relaxed">{questions[currentQuestion]?.analysis}</p>
                        <p className="text-amber-700 text-xs mt-2">
                          正确答案：<span className="font-medium">{String.fromCharCode(65 + questions[currentQuestion]?.correct_answer)}</span>
                        </p>
                      </div>
                    </div>
                  </motion.div>
                )}

                <div className="flex gap-3">
                  {showAnalysis !== currentQuestion && answers[currentQuestion] !== undefined && (
                    <button
                      onClick={() => setShowAnalysis(currentQuestion)}
                      className="px-6 py-3 border border-slate-300 text-slate-700 hover:bg-slate-50 transition-colors"
                    >
                      查看解析
                    </button>
                  )}
                  <button
                    onClick={nextQuestion}
                    disabled={answers[currentQuestion] === undefined}
                    className="flex-1 py-3 bg-slate-900 text-white font-medium disabled:opacity-50 disabled:cursor-not-allowed hover:bg-slate-800 transition-all flex items-center justify-center gap-2"
                  >
                    {currentQuestion === questions.length - 1 ? '提交测评' : '下一题'}
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        ) : result && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-white border border-slate-200 p-8">
              <div className="text-center mb-8">
                <div className="inline-flex items-center justify-center w-20 h-20 bg-slate-900 mb-4">
                  <Award className="w-10 h-10 text-white" />
                </div>
                <h2 className="text-2xl font-bold text-slate-900 tracking-tight mb-2">测评完成!</h2>
                <p className="text-slate-500">用时: {formatTime(elapsedTime)}</p>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-slate-900 p-6 text-white text-center">
                  <div className="text-3xl font-bold">{result.percentage}%</div>
                  <div className="text-sm opacity-80">正确率</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 p-6 text-center">
                  <div className="text-3xl font-bold text-slate-900">{result.score}/{result.totalScore}</div>
                  <div className="text-sm text-slate-500">得分</div>
                </div>
                <div className="bg-slate-50 border border-slate-200 p-6 text-center">
                  <div className="text-3xl font-bold text-slate-900">{result.correctCount}/{result.totalCount}</div>
                  <div className="text-sm text-slate-500">答对题数</div>
                </div>
                <div className="bg-emerald-600 p-6 text-white text-center">
                  <div className="text-2xl font-bold">{result.estimatedScoreRange.min}-{result.estimatedScoreRange.max}</div>
                  <div className="text-sm opacity-80">预估高考分</div>
                </div>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-slate-700" />
                    模块掌握情况
                  </h3>
                  <div className="space-y-3">
                    {Object.entries(result.moduleStats).map(([module, stats]) => {
                      const percentage = Math.round((stats.score / stats.totalScore) * 100);
                      return (
                        <div key={module} className="bg-slate-50 border border-slate-200 p-4">
                          <div className="flex justify-between items-center mb-2">
                            <span className="font-medium text-slate-900">{module}</span>
                            <span className={`text-sm font-medium ${percentage >= 80 ? 'text-emerald-600' : percentage >= 60 ? 'text-slate-700' : 'text-rose-600'}`}>
                              {stats.correct}/{stats.total} ({percentage}%)
                            </span>
                          </div>
                          <div className="h-1 bg-slate-200">
                            <div
                              className={`h-full transition-all ${percentage >= 80 ? 'bg-emerald-500' : percentage >= 60 ? 'bg-slate-700' : 'bg-rose-500'}`}
                              style={{ width: `${percentage}%` }}
                            />
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-slate-900 mb-4 flex items-center gap-2">
                    <Target className="w-5 h-5 text-slate-700" />
                    知识点掌握情况
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {Object.entries(result.knowledgeStats).map(([knowledge, stats]) => {
                      const percentage = Math.round((stats.score / stats.totalScore) * 100);
                      return (
                        <div key={knowledge} className="bg-slate-50 border border-slate-200 p-3 flex items-center justify-between">
                          <span className="text-sm text-slate-700">{knowledge}</span>
                          <span className={`text-xs px-2 py-1 border ${percentage >= 80 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : percentage >= 60 ? 'bg-slate-100 text-slate-700 border-slate-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
                            {percentage}%
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {result.strongPoints.length > 0 && (
                  <div className="bg-emerald-50 border border-emerald-200 p-6">
                    <h3 className="font-semibold text-emerald-900 mb-3 flex items-center gap-2">
                      <CheckCircle className="w-5 h-5" />
                      优势知识点
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {result.strongPoints.map((point) => (
                        <span key={point} className="px-3 py-1 bg-emerald-100 text-emerald-800 text-sm">
                          {point}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {result.weakPoints.length > 0 && (
                  <div className="bg-rose-50 border border-rose-200 p-6">
                    <h3 className="font-semibold text-rose-900 mb-3 flex items-center gap-2">
                      <XCircle className="w-5 h-5" />
                      薄弱环节
                    </h3>
                    <div className="flex flex-wrap gap-2">
                      {result.weakPoints.map((point) => (
                        <span key={point} className="px-3 py-1 bg-rose-100 text-rose-800 text-sm">
                          {point}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                <div className="bg-slate-50 border border-slate-200 p-6">
                  <h3 className="font-semibold text-slate-900 mb-3 flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-slate-700" />
                    备考建议
                  </h3>
                  <ul className="space-y-2">
                    {result.suggestions.map((suggestion, index) => (
                      <li key={index} className="flex items-start gap-2 text-slate-700 text-sm">
                        <span className="w-1.5 h-1.5 bg-slate-400 mt-1.5 flex-shrink-0" />
                        {suggestion}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <button
                  onClick={restartAssessment}
                  className="flex-1 py-3 border-2 border-slate-900 text-slate-900 font-medium hover:bg-slate-50 transition-colors flex items-center justify-center gap-2"
                >
                  <RotateCcw className="w-5 h-5" />
                  重新测评
                </button>
                <button
                  onClick={resetAssessment}
                  className="flex-1 py-3 bg-slate-900 text-white font-medium hover:bg-slate-800 transition-all"
                >
                  选择其他科目
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
