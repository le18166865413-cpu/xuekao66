import { motion } from 'framer-motion';
import { Target, Award, Users, Phone } from 'lucide-react';

const milestones = [
  { year: '2018', title: '公司成立', desc: '学考合一教育科技正式成立' },
  { year: '2019', title: '平台上线', desc: '在线教育平台正式发布' },
  { year: '2020', title: 'AI测评', desc: '智能测评系统上线' },
  { year: '2021', title: '百万学员', desc: '累计服务学员突破百万' },
  { year: '2023', title: '行业领先', desc: '成为行业头部教育品牌' },
];

const team = [
  { name: '陈明远', role: '创始人CEO', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=ceo' },
  { name: '林雅婷', role: '教学总监', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=lin' },
  { name: '王志强', role: '技术总监', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=wang' },
];

export default function About() {
  return (
    <div className="min-h-screen bg-white pt-20">
      <section className="py-20 bg-slate-50 border-b border-slate-100">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-4xl font-bold text-slate-900 tracking-tight mb-6"
          >
            关于学考合一
          </motion.h1>
          <p className="text-lg text-slate-500 max-w-2xl mx-auto">
            专注教育提分，汇聚名师资源，为每一位学生提供个性化的学习方案
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <h2 className="text-3xl font-bold text-slate-900 tracking-tight mb-6">公司介绍</h2>
              <p className="text-slate-600 leading-relaxed mb-4">
                学考合一教育科技有限公司成立于2018年，是一家专注于K12在线教育的科技企业。
              </p>
              <p className="text-slate-600 leading-relaxed">
                我们依托AI技术和优质师资，为学生提供个性化学习方案，累计帮助超过50万学生实现成绩提升。
              </p>
            </motion.div>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Target, label: '专注提分', value: '6年' },
                { icon: Award, label: '行业认证', value: '20+' },
                { icon: Users, label: '服务学员', value: '50万+' },
                { icon: Phone, label: '客服支持', value: '7×24' },
              ].map((item, i) => (
                <motion.div
                  key={item.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="bg-slate-50 border border-slate-200 p-6 text-center"
                >
                  <item.icon className="w-8 h-8 text-slate-700 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-slate-900">{item.value}</div>
                  <div className="text-sm text-slate-500">{item.label}</div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-slate-50 border-t border-slate-100">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-slate-900 tracking-tight mb-12">发展历程</h2>
          <div className="flex flex-wrap justify-center gap-6">
            {milestones.map((m, i) => (
              <motion.div
                key={m.year}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="bg-white border border-slate-200 p-6 w-48 text-center"
              >
                <div className="text-slate-900 font-bold text-xl mb-2">{m.year}</div>
                <div className="font-semibold text-slate-900 mb-1">{m.title}</div>
                <div className="text-sm text-slate-500">{m.desc}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-3xl font-bold text-center text-slate-900 tracking-tight mb-12">核心团队</h2>
          <div className="flex flex-wrap justify-center gap-8">
            {team.map((member, i) => (
              <motion.div
                key={member.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center"
              >
                <img
                  src={member.avatar}
                  alt={member.name}
                  className="w-24 h-24 mx-auto mb-4 bg-slate-100"
                />
                <div className="font-bold text-slate-900">{member.name}</div>
                <div className="text-slate-500">{member.role}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
