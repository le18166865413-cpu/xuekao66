import { useState } from 'react';
import { motion } from 'framer-motion';
import { Search, Filter, Star, Users, Clock, ChevronRight } from 'lucide-react';

const categories = [
  { id: 'all', name: '全部课程' },
  { id: 'math', name: '数学' },
  { id: 'english', name: '英语' },
  { id: 'physics', name: '物理' },
  { id: 'chemistry', name: '化学' },
  { id: 'chinese', name: '语文' },
];

const grades = [
  { id: 'all', name: '全部学段' },
  { id: 'primary', name: '小学' },
  { id: 'junior', name: '初中' },
  { id: 'senior', name: '高中' },
];

const courses = [
  {
    id: 1,
    title: '高考数学冲刺班',
    teacher: '张老师',
    subject: 'math',
    grade: 'senior',
    students: 2580,
    rating: 4.9,
    price: 1299,
    originalPrice: 1999,
    duration: '48课时',
    image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&h=250&fit=crop',
    tags: ['热门', '提分快']
  },
  {
    id: 2,
    title: '英语语法精讲',
    teacher: '李老师',
    subject: 'english',
    grade: 'senior',
    students: 1890,
    rating: 4.8,
    price: 899,
    originalPrice: 1299,
    duration: '36课时',
    image: 'https://images.unsplash.com/photo-1543269865-cbf427effbad?w=400&h=250&fit=crop',
    tags: ['推荐']
  },
  {
    id: 3,
    title: '物理高分攻略',
    teacher: '王老师',
    subject: 'physics',
    grade: 'senior',
    students: 1200,
    rating: 4.9,
    price: 1099,
    originalPrice: 1599,
    duration: '42课时',
    image: 'https://images.unsplash.com/photo-1636466497217-26a8cbeaf0aa?w=400&h=250&fit=crop',
    tags: ['新课']
  },
  {
    id: 4,
    title: '化学实验专项',
    teacher: '赵老师',
    subject: 'chemistry',
    grade: 'senior',
    students: 980,
    rating: 4.7,
    price: 799,
    originalPrice: 1199,
    duration: '30课时',
    image: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?w=400&h=250&fit=crop',
    tags: ['特色']
  },
  {
    id: 5,
    title: '初中数学基础',
    teacher: '陈老师',
    subject: 'math',
    grade: 'junior',
    students: 3200,
    rating: 4.8,
    price: 699,
    originalPrice: 999,
    duration: '40课时',
    image: 'https://images.unsplash.com/photo-1509228465528-978c0ca4e9bd?w=400&h=250&fit=crop',
    tags: ['基础']
  },
  {
    id: 6,
    title: '小学语文阅读',
    teacher: '刘老师',
    subject: 'chinese',
    grade: 'primary',
    students: 4500,
    rating: 4.9,
    price: 599,
    originalPrice: 899,
    duration: '32课时',
    image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?w=400&h=250&fit=crop',
    tags: ['热门']
  },
];

export default function Courses() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeGrade, setActiveGrade] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredCourses = courses.filter(course => {
    const matchCategory = activeCategory === 'all' || course.subject === activeCategory;
    const matchGrade = activeGrade === 'all' || course.grade === activeGrade;
    const matchSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchGrade && matchSearch;
  });

  return (
    <div className="min-h-screen bg-white pt-20">
      <div className="bg-slate-50 border-b border-slate-100 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight mb-3">课程中心</h1>
          <p className="text-slate-500">精选优质课程，助力学业提升</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="bg-white border border-slate-200 p-6 mb-10">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="搜索课程..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-slate-200 focus:outline-none focus:border-slate-400 transition-colors"
              />
            </div>
            <div className="flex items-center gap-2 text-slate-600">
              <Filter className="w-5 h-5" />
              <span>筛选</span>
            </div>
          </div>

          <div className="mt-6 space-y-4">
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-sm text-slate-500 mr-2">学科：</span>
              {categories.map(cat => (
                <button
                  key={cat.id}
                  onClick={() => setActiveCategory(cat.id)}
                  className={`px-4 py-2 text-sm transition-all border ${
                    activeCategory === cat.id
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-slate-400'
                  }`}
                >
                  {cat.name}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap gap-2 items-center">
              <span className="text-sm text-slate-500 mr-2">学段：</span>
              {grades.map(grade => (
                <button
                  key={grade.id}
                  onClick={() => setActiveGrade(grade.id)}
                  className={`px-4 py-2 text-sm transition-all border ${
                    activeGrade === grade.id
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-600 border-slate-200 hover:border-slate-400'
                  }`}
                >
                  {grade.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCourses.map((course, index) => (
            <motion.div
              key={course.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              className="bg-white border border-slate-200 overflow-hidden cursor-pointer group hover:border-slate-400 transition-all"
            >
              <div className="relative">
                <img
                  src={course.image}
                  alt={course.title}
                  className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3 flex gap-2">
                  {course.tags.map(tag => (
                    <span key={tag} className="px-2 py-1 bg-slate-900 text-white text-xs">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-lg font-semibold text-slate-900 mb-2 tracking-tight">{course.title}</h3>
                <p className="text-sm text-slate-500 mb-3">{course.teacher}</p>
                <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {course.students}人
                  </span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-amber-500 fill-amber-500" />
                    {course.rating}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    {course.duration}
                  </span>
                </div>
                <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold text-slate-900">¥{course.price}</span>
                    <span className="text-sm text-slate-400 line-through">¥{course.originalPrice}</span>
                  </div>
                  <button className="flex items-center gap-1 text-slate-900 hover:text-slate-600 font-medium">
                    详情
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
