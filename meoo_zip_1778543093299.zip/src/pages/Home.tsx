import { motion } from 'framer-motion';
import Hero from '../components/Hero';
import Features from '../components/Features';
import Teachers from '../components/Teachers';
import Courses from '../components/Courses';
import Testimonials from '../components/Testimonials';
import Partners from '../components/Partners';
import CTA from '../components/CTA';

const fadeInUp = {
  initial: { opacity: 0, y: 40 },
  whileInView: { opacity: 1, y: 0 },
  viewport: { once: true, margin: "-100px" },
  transition: { duration: 0.6, ease: [0.25, 0.1, 0.25, 1] }
};

const staggerContainer = {
  initial: {},
  whileInView: {},
  viewport: { once: true, margin: "-100px" }
};

export default function Home() {
  return (
    <motion.main
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.5 }}
    >
      <Hero />
      
      <motion.section {...fadeInUp}>
        <Features />
      </motion.section>
      
      <motion.section {...fadeInUp}>
        <Teachers />
      </motion.section>
      
      <motion.section {...fadeInUp}>
        <Courses />
      </motion.section>
      
      <motion.section {...fadeInUp}>
        <Testimonials />
      </motion.section>
      
      <motion.section {...fadeInUp}>
        <Partners />
      </motion.section>
      
      <motion.section {...fadeInUp}>
        <CTA />
      </motion.section>
    </motion.main>
  );
}
