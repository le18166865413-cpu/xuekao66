import { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, FileText, Filter, Search } from 'lucide-react';

const categories = [
  { id: 'all', name: '全部' },
  { id: 'math', name: '数学' },
  { id: 'english', name: '英语' },
  { id: 'physics', name: '物理' },
  { id: 'chemistry', name: '化学' },
];

const types = [
  { id: 'all', name: '全部类型' },
  { id: 'exam', name: '真题试卷' },
  { id: 'notes', name: '学霸笔记' },
  { id: 'formula', name: '公式大全' },
];

const materials = [
  { id: 1, title: '2024高考数学真题汇编', category: 'math', type: 'exam', downloads: 12580, size: '15.2MB' },
  { id: 2, title: '高中英语词汇速记手册', category: 'english', type: 'notes', downloads: 8960, size: '8.5MB' },
  { id: 3, title: '物理公式大全', category: 'physics', type: 'formula', downloads: 7230, size: '5.3MB' },
  { id: 4, title: '化学方程式汇总', category: 'chemistry', type: 'formula', downloads: 6540, size: '4.8MB' },
  { id: 5, title: '高考英语阅读理解技巧', category: 'english', type: 'notes', downloads: 5890, size: '6.2MB' },
  { id: 6, title: '数学压轴题解析', category: 'math', type: 'exam', downloads: 9870, size: '12.1MB' },
];

export default function Materials() {
  const [activeCategory, setActiveCategory] = useState('all');
  const [activeType, setActiveType] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const filteredMaterials = materials.filter(item => {
    const matchCategory = activeCategory === 'all' || item.category === activeCategory;
    const matchType = activeType === 'all' || item.type === activeType;
    const matchSearch = item.title.toLowerCase().includes(searchQuery.toLowerCase());
    return matchCategory && matchType && matchSearch;
  });

  return (
    <div className="min-h-screen bg-white pt-20 pb-20">
      <div className="bg-slate-50 border-b border-slate-100 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-3xl md:text-4xl font-bold text-slate-900 tracking-tight mb-3">免费资料</h1>
          <p className="text-slate-500">海量学习资料，助力高效备考</p>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="bg-white border border-slate-200 p-6 mb-10">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                placeholder="搜索资料..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border border-slate-200 focus:outline-none focus:border-slate-400 transition-colors"
              />
            </div>
            <div className="flex gap-2">
              <select
                value={activeCategory}
                onChange={(e) => setActiveCategory(e.target.value)}
                className="px-4 py-3 border border-slate-200 focus:outline-none focus:border-slate-400 bg-white"
              >
                {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
              </select>
              <select
                value={activeType}
                onChange={(e) => setActiveType(e.target.value)}
                className="px-4 py-3 border border-slate-200 focus:outline-none focus:border-slate-400 bg-white"
              >
                {types.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMaterials.map((item, index) => (
            <motion.div
              key={item.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              className="bg-white border border-slate-200 p-6 hover:border-slate-400 transition-all"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 bg-slate-100 flex items-center justify-center">
                  <FileText className="w-6 h-6 text-slate-700" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-slate-900 mb-1 tracking-tight">{item.title}</h3>
                  <p className="text-sm text-slate-500 mb-4">{item.size} · {item.downloads}次下载</p>
                  <button className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white hover:bg-slate-800 transition-colors">
                    <Download className="w-4 h-4" />
                    免费下载
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
